Quick start

First, add the webapp:

1. Add "webapp" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'webapp',
    ]

2. Include the webapp URLconf in your project urls.py like this::

    path('webapp/', include('webapp.urls', namespace='webapp')),
   



    
Then repeat for the "accounts" application:

1. Add "accounts" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'accounts',
    ]

2. Include the webapp URLconf in your project urls.py like this::

    path('accounts/', include('accounts.urls', namespace='accounts')),





Then finally:

3. Run ``python manage.py migrate`` to create the webapp models.

4. Visit http://127.0.0.1:8000/webapp/ to use the application.

